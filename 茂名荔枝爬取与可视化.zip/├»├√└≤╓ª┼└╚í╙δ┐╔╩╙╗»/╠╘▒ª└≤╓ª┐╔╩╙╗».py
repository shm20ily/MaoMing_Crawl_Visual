import os
from snapshot_selenium import snapshot as driver
from pyecharts.render import make_snapshot
import pandas as pd
import numpy as np
import re


# 导入爬取得到的数据
df = pd.read_csv("淘宝荔枝.csv", engine='python', encoding='utf-8-sig', header=None)
df.columns = ["商品名", "价格", "付款人数", "店铺", "发货地址"]
# print(df.head(10))
# 去除重复值
df.drop_duplicates(inplace=True)
# 处理购买人数为空的记录
df['付款人数'] = df['付款人数'].replace(np.nan, '0人付款')
# 提取数值
df['num'] = [re.findall(r'(\d+\.{0,1}\d*)', i)[0] for i in df['付款人数']]  # 提取数值
df['num'] = df['num'].astype('float')  # 转化数值型
# 提取单位（万）
df['unit'] = [''.join(re.findall(r'(万)', i)) for i in df['付款人数']]  # 提取单位（万）
df['unit'] = df['unit'].apply(lambda x: 10000 if x == '万' else 1)
# 计算销量
df['销量'] = df['num'] * df['unit']
# # 删除无发货地址的商品，并提取省份
df = df[df['发货地址'].notna()]
# df['省份'] = df['发货地址'].str.split(' ').apply(lambda x: x[0])
# 删除多余的列
df.drop(['付款人数', 'num', 'unit'], axis=1, inplace=True)
# 重置索引
df = df.reset_index(drop=True)
# print(df.head(10))
# df.to_csv('淘宝茂名荔枝数据.csv', encoding='utf-8-sig', index=False)
df1 = df.sort_values(by="价格", axis=0, ascending=False)
# print(df1.iloc[:5, :])

# import jieba.analyse
#
# txt = df['商品名'].str.cat(sep='。')
# # 添加关键词
# jieba.add_word('粽子', 999, '五芳斋')
# # 读入停用词表
# stop_words = []
# with open('stopwords.txt', 'r', encoding='utf-8') as f:
#     lines = f.readlines()
#     for line in lines:
#         stop_words.append(line.strip())
# # 添加停用词
# stop_words.extend(['logo', '10', '100', '200g', '100g', '140g', '130g'])
# # 评论字段分词处理
# word_num = jieba.analyse.extract_tags(txt,
#                                       topK=100,
#                                       withWeight=True,
#                                       allowPOS=())
# # 去停用词
# word_num_selected = []
#
# for i in word_num:
#     if i[0] not in stop_words:
#         word_num_selected.append(i)
#
# key_words = pd.DataFrame(word_num_selected, columns=['words', 'num'])

# 导入包
from pyecharts.charts import Bar
from pyecharts import options as opts

# # 计算top10店铺
# shop_top10 = df.groupby('商品名')['销量'].sum().sort_values(ascending=False).head(10)
# # 绘制柱形图
# bar0 = Bar(init_opts=opts.InitOpts(width='1350px', height='750px'))
# bar0.add_xaxis(shop_top10.index.tolist())
# bar0.add_yaxis('淘宝荔枝商品销量Top10', shop_top10.values.tolist())
# bar0.set_global_opts(  # title_opts=opts.TitleOpts(title='荔枝商品销量Top10'),
#     xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15), name='商品名'),
#     yaxis_opts=opts.AxisOpts(name='销量'),
#     visualmap_opts=opts.VisualMapOpts(max_=shop_top10.values.max()))
# make_snapshot(driver, bar0.render("淘宝荔枝商品销量Top10.html"), '.\oat\淘宝荔枝商品销量Top10.png')
# os.system("淘宝荔枝商品销量Top10.html")


# from pyecharts.charts import Pie
#
#
def price_range(x):  # 按照淘宝推荐划分价格区间
    if x <= 39:
        return '39元以下'
    elif x <= 86:
        return '39-86元'
    elif x <= 86:
        return '86-179元'
    else:
        return '179元以上'


df['price_range'] = df['价格'].apply(lambda x: price_range(x))
price_cut_num = df.groupby('price_range')['销量'].sum()
print(price_cut_num)
# data_pair = [list(z) for z in zip(price_cut_num.index, price_cut_num.values)]
# print(data_pair)
# # 饼图
# pie1 = Pie(init_opts=opts.InitOpts(width='1350px', height='750px'))
# # 内置富文本
# pie1.add(
#     series_name="销量",
#     radius=["35%", "55%"],
#     data_pair=data_pair,
#     label_opts=opts.LabelOpts(formatter='{{b}—占比{d}%}'),
# )
# pie1.set_global_opts(legend_opts=opts.LegendOpts(pos_left="left", pos_top='30%', orient="vertical"),
#                      # title_opts=opts.TitleOpts(title='不同价格区间的荔枝销量占比'),
#                      toolbox_opts=opts.ToolboxOpts())
# make_snapshot(driver, pie1.render("不同价格区间的荔枝销量占比.html"), '.\oat\不同价格区间的荔枝销量占比.png')
# os.system("不同价格区间的荔枝销量占比.html")


# from pyecharts.charts import WordCloud
# from pyecharts.globals import SymbolType
#
# # 词云图
# word1 = WordCloud(init_opts=opts.InitOpts(width='1350px', height='750px'))
# word1.add("", [*zip(key_words.words, key_words.num)],
#           word_size_range=[20, 200],
#           shape=SymbolType.DIAMOND)
# word1.set_global_opts(  # title_opts=opts.TitleOpts('淘宝荔枝商品名称词云图'),
#     toolbox_opts=opts.ToolboxOpts())
# make_snapshot(driver, word1.render('淘宝荔枝商品名称词云图.html'), '.\oat\淘宝荔枝商品名称词云图.png')
# # os.system("淘宝荔枝商品名称词云图.html")
