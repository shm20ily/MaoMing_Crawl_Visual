import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import pandas as pd
from matplotlib import ticker
import seaborn as sns
import numpy as np
import matplotlib.patches as mpatches
from matplotlib.ticker import PercentFormatter

# 中文乱码的处理
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

# # GDP = [6.06, 10.73, 41.35, 28.2, 13.67]
# GDP = [4.84, 5.88, 44.29, 31.14, 13.84]
#
# # 转换成pandas数据类型
# pd_data = pd.DataFrame(GDP, index=[i + 1 for i in range(5)], columns=['Value'])
# pd_data['Num'] = [i + 1 for i in range(5)]
#
# # 绘制柱状图
# ax = sns.barplot(x='Num', y='Value', data=pd_data)
# # 添加标题
# # plt.title('在相同价格下，更倾向于选择购买茂名荔枝同意程度')
# plt.title('再次购买茂名荔枝同意程度')
# # 添加刻度标签
# plt.xticks(range(5), ['完全不同意', '比较不同意', '一般', '比较同意', '完全同意'])
# # 为每个条形图添加数值标签
# for x, y in enumerate(GDP):
#     plt.text(x, y + 0.5, '%.2f%%' % y, ha='center')
# # 将纵坐标格式转化为百分比形式
# ax.yaxis.set_major_formatter(ticker.PercentFormatter(xmax=100, decimals=0))
# # 绘制平行于x轴的虚线
# for i in range(1, 5, 1):
#     plt.axhline(y=i*10, linestyle='dashed', color='black', linewidth=0.5)
# plt.show()


# # labels = ['品牌同意程度', '品质同意程度', '性价比同意程度']
# labels = ['冷链物流', '售后服务']
# legends = ['完全不同意', '比较不同意', '一般', '比较同意', '完全同意']
# first = [6.23, 8.48, 48.27, 25.61, 11.42]
# second = [6.06, 7.27, 46.02, 29.41, 11.25]
# third = [5.36, 8.3, 46.54, 28.89, 10.9]
# fourth = [4.33, 7.96, 51.38, 25.95, 10.38]
# others = [4.67, 6.4, 53.46, 25.61, 9.86]
# # data = [first, second, third]
# data = [fourth, others]
# data = np.array(data)
# data = pd.DataFrame(data, index=labels, columns=legends)
#
#
# def percentage_bar(df):
#     labels = df.index.tolist()  # 提取分类显示标签
#     results = df.to_dict(orient='list')  # 将数值结果转化为字典
#     category_names = list(results.keys())  # 提取字典里面的类别（键-key）
#     data = np.array(list(results.values()))  # 提取字典里面的数值（值-value）
#
#     category_colors = plt.get_cmap('RdYlGn')(np.linspace(0.15, 0.85, data.shape[0]))
#     # 设置占比显示的颜色，可以自定义，修改括号里面的参数即可，如下
#     # category_colors = plt.get_cmap('hot')(np.linspace(0.15, 0.85, data.shape[0]))
#
#     fig, ax = plt.subplots(figsize=(12, 9))  # 创建画布，开始绘图
#     ax.invert_xaxis()  # 这个可以通过设置df中columns的顺序调整
#     ax.yaxis.set_visible(False)  # 设置y轴刻度不可见
#     ax.set_xticklabels(labels=labels, rotation=90)  # 显示x轴标签，并旋转90度
#     ax.set_ylim(0, 1)  # 设置y轴的显示范围
#     starts = 0  # 绘制基准
#     for i, (colname, color) in enumerate(zip(category_names, category_colors)):
#         heights = data[i, :] / data.sum(axis=0)  # 计算出每次遍历时候的百分比
#         ax.bar(labels, heights, bottom=starts, width=0.5, label=colname, color=color, edgecolor='gray')  # 绘制柱状图
#         xcenters = starts + heights / 2  # 进行文本标记位置的选定
#         starts += heights  # 核心一步，就是基于基准上的百分比累加
#         # print(starts) 这个变量就是能否百分比显示的关键，可以打印输出看一下
#         percentage_text = data[i, :] / data.sum(axis=0)  # 文本标记的数据
#
#         r, g, b, _ = color  # 这里进行像素的分割
#         text_color = 'white' if r * g * b < 0.5 else 'k'  # 根据颜色基调分配文本标记的颜色
#         for y, (x, c) in enumerate(zip(xcenters, percentage_text)):
#             ax.text(y, x, f'{round(c * 100, 2)}%', ha='center', va='center',
#                     color=text_color, rotation=0)  # 添加文本标记
#     ax.legend(ncol=len(category_names), bbox_to_anchor=(0, 1),
#               loc='lower left', fontsize='large')  # 设置图例
#     return fig, ax  # 返回图像
#
#
# percentage_bar(data)
# plt.xticks(rotation=0)
# plt.show()

# # 绘制饼图
# # values = [4.67, 83.39, 6.57, 2.42, 2.77, 0.17]
# # feature = ['18岁以下', '18-30岁', '31-40岁', '41-50岁', '51-60岁', '60岁以上']
# # 对荔枝喜爱程度
# values = [30.28, 48.96, 17.99, 2.25, 0.52]
# feature = ['非常喜欢', '比较喜欢', '一般', '不太喜欢', '讨厌']
# # 将横、纵坐标轴标准化处理，保证饼图是一个正圆，否则为椭圆
# plt.axes(aspect='equal')
# # 控制x轴和y轴的范围
# plt.xlim(0, 4)
# plt.ylim(0, 4)
# wedges, texts, autotexts = plt.pie(x=values,  # 绘图数据
#                                    # wedgeprops={'width': 0.8},  # 定义边缘的宽度（环形图）
#                                    autopct='%.1f%%',  # 设置百分比的格式，这里保留一位小数
#                                    pctdistance=1,  # 设置百分比标签与圆心的距离
#                                    startangle=180,  # 设置饼图的初始角度
#                                    radius=2,  # 设置饼图的半径
#                                    counterclock=False,  # 是否逆时针，这里设置为顺时针方向
#                                    textprops={'fontsize': 12, 'color': 'k'},  # 设置文本标签的属性值
#                                    center=(1.8, 1.8))  # 设置饼图的原点
# plt.legend(wedges,
#            feature,
#            fontsize=12,
#            loc='center left',
#            bbox_to_anchor=(1, 0, 0.5, 1))
# # 删除x轴和y轴的刻度
# plt.xticks(())
# plt.yticks(())
# plt.tight_layout()
# # 显示图形
# plt.show()

a = [71, 138, 205, 118, 46]
b = [32, 46, 193, 242, 65]
c = [65, 157, 195, 116, 45]
d = [32, 50, 221, 217, 58]
e = [25, 39, 184, 273, 57]
f = [24, 16, 147, 266, 125]
g = [21, 15, 140, 270, 132]
h = [21, 29, 259, 199, 70]
j = [26, 28, 295, 170, 59]
l = [24, 34, 272, 183, 65]
data = [a, b, c, d, e, f, g, h, j, l]
labels = ['相比鲜果我更加喜欢预制菜（精加工产品）', '对于预制菜我更倾向于购买有品牌的产品',
          '我在购买时只看品牌不会注意价格', '我在购买时会潜意识觉得在助力乡村振兴',
          '我在购买时会注意外包装是否符合我心意', '我希望我线上购买时物流完善且快速',
          '我希望我线下购买时可以有多种选择', '我很看好荔枝预制菜（精加工产品）在国内的销量',
          '我觉得荔枝预制菜（精加工产品）在国外销量不错', '我很看好荔枝预制菜（精加工产品）在国外的销量']
data = np.array(data).T
data = pd.DataFrame(data, columns=labels)
corr = data.corr()
fig, ax = plt.subplots(figsize=(14, 14))
sns.heatmap(corr, annot=True)   # cmap='Accent'
plt.tight_layout()
plt.show()
fig.savefig('df_corr.png', bbox_inches='tight', transparent=True)
