import pandas as pd
import numpy as np
import re
from snapshot_selenium import snapshot as driver
from pyecharts.render import make_snapshot
import os

# 导入爬取得到的数据
df = pd.read_csv("惠农网荔枝供应数据.csv", engine='python', encoding='utf-8-sig')
df.drop_duplicates(inplace=True)
df.dropna(inplace=True)
df['询价量'] = df['询价量'].astype('int64')
# df.to_csv('惠农网茂名荔枝供应数据.csv', encoding='utf-8-sig', index=False)
# pd.set_option('display.max_columns', None)
# print(df.head(10))
df.info()

from pyecharts import options as opts
from pyecharts.charts import Bar

# 计算top10店铺
# shop_top10 = df['价格'].value_counts().head(20)
# print(shop_top10)
shop_top10 = df.groupby('商品名')['成交量'].sum().sort_values(ascending=False).head(20)
# print(shop_top10)
# # 绘制柱形图
# bar0 = Bar(init_opts=opts.InitOpts(width='1350px', height='750px'))
# bar0.add_xaxis(shop_top10.index.tolist())
# bar0.add_yaxis('惠农网荔枝商品收藏次数Top10', shop_top10.values.tolist())
# bar0.set_global_opts(  # title_opts=opts.TitleOpts(title='荔枝商品成交量Top10'),
#     xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15), name='商品名'),
#     yaxis_opts=opts.AxisOpts(name='收藏次数'),
#     visualmap_opts=opts.VisualMapOpts(max_=shop_top10.values.max()))
# make_snapshot(driver, bar0.render("惠农网荔枝商品收藏次数Top10.html"), '惠农网荔枝商品收藏次数Top10.png')
# os.system("惠农网荔枝商品收藏次数Top10.html")

from pyecharts.charts import Geo

area_num = df.groupby('发货地址')['询价量'].sum().sort_values(ascending=False)
print(area_num)
area_np = list(zip(area_num.index.tolist(), area_num.values.tolist()))

# area_values = []
# for num in area_num.values:
#     bai = '{:.2f}'.format(num / area_num.values.sum() * 100)
#     area_values.append(bai)
# area_np = list(zip(area_num.index.tolist(), area_values))
# print(area_np)
pieces = [
    # 询价量
    {'min': 2000, 'max': 4000, 'label': '2000-4000', 'color': '#3700A4'},
    {'min': 4000, 'max': 10000, 'label': '4000-10000', 'color': '	#FF0000'},  # 红色
    {'min': 10000, 'max': 30000, 'label': '10000-30000', 'color': '#FF8C00'},  # 橙色
    {'min': 30000, 'max': 40000, 'label': '30000-40000', 'color': '#333333'},
    {'min': 40000, 'max': 50000, 'label': '40000-50000', 'color': '#0000FF'}  # 蓝色
    # # 成交量
    # {'min': 0, 'max': 1, 'label': '0-1', 'color': '#3700A4'},
    # {'min': 2, 'max': 5, 'label': '2-5', 'color': '	#FF0000'},  # 红色
    # {'min': 6, 'max': 10, 'label': '6-10', 'color': '#FF8C00'},  # 橙色
    # {'min': 200, 'max': 300, 'label': '200-300', 'color': '#333333'},
    # {'min': 300, 'max': 400, 'label': '300-400', 'color': '#0000FF'}  # 蓝色
    # # 收藏量
    # {'min': 1, 'max': 10, 'label': '1-10', 'color': '#3700A4'},
    # {'min': 11, 'max': 20, 'label': '11-20', 'color': '	#FF0000'},  # 红色
    # {'min': 100, 'max': 150, 'label': '100-150', 'color': '#FF8C00'},  # 橙色
    # {'min': 200, 'max': 300, 'label': '200-300', 'color': '#333333'},
    # {'min': 1000, 'max': 1100, 'label': '1000-1100', 'color': '#0000FF'}  # 蓝色
    # # 采购热度
    # {'min': 0, 'max': 3, 'label': '0-3%', 'color': '#3700A4'},
    # {'min': 5, 'max': 8, 'label': '5-8%', 'color': '	#FF0000'},  # 红色
    # {'min': 8, 'max': 20, 'label': '8-20%', 'color': '#FF8C00'},  # 橙色
    # {'min': 20, 'max': 30, 'label': '20-30%', 'color': '#333333'},
    # {'min': 50, 'max': 60, 'label': '50-60%', 'color': '#0000FF'}  # 蓝色
]
c = (
    Geo()
    .add_schema(maptype='茂名')
    .add_coordinate('电白区', 111.01, 21.51)
    .add("茂名各地区荔枝询价人数分布", area_np)
    .set_global_opts(visualmap_opts=opts.VisualMapOpts(max_=300, is_piecewise=True, pieces=pieces),
                     toolbox_opts=opts.ToolboxOpts())
    .set_series_opts(label_opts=opts.LabelOpts(is_show=True, formatter='{b}\n{c}'))
)
make_snapshot(driver, c.render('茂名各地区荔枝询价人数分布.html'), '.\geo\茂名各地区荔枝询价人数分布.png')
os.system("茂名各地区荔枝询价人数分布.html")


# from pyecharts.charts import Map
#
# # 计算销量
# province_num = df.groupby('发货地址')['采购热度'].sum().sort_values(ascending=False)
# print(province_num)
# # 绘制地图
# map1 = Map(init_opts=opts.InitOpts(width='1350px', height='750px'))
# map1.add("茂名各地区荔枝采购热度分布", [list(z) for z in zip(province_num.index.tolist(), province_num.values.tolist())],
#          maptype='茂名')
# map1.set_global_opts(visualmap_opts=opts.VisualMapOpts(max_=1300),
#                      toolbox_opts=opts.ToolboxOpts())
# make_snapshot(driver, map1.render('茂名各地区荔枝采购热度分布.html'), '.\map\茂名各地区荔枝采购热度分布.png')
# os.system("茂名各地区荔枝采购热度分布.html")


# import jieba.analyse
# from pyecharts.charts import WordCloud
# from pyecharts.globals import SymbolType
#
# txt = df['商品名'].str.cat(sep='。')
# # 添加关键词
# jieba.add_word('粽子', 999, '五芳斋')
# # 读入停用词表
# stop_words = []
# with open('stopwords.txt', 'r', encoding='utf-8') as f:
#     lines = f.readlines()
#     for line in lines:
#         stop_words.append(line.strip())
# # 添加停用词
# stop_words.extend(['logo', '10', '100', '200g', '100g', '140g', '130g'])
# # 评论字段分词处理
# word_num = jieba.analyse.extract_tags(txt,
#                                       topK=100,
#                                       withWeight=True,
#                                       allowPOS=())
# # 去停用词
# word_num_selected = []
#
# for i in word_num:
#     if i[0] not in stop_words:
#         word_num_selected.append(i)
#
# key_words = pd.DataFrame(word_num_selected, columns=['words', 'num'])
#
# # 词云图
# word1 = WordCloud(init_opts=opts.InitOpts(width='1350px', height='750px'))
# word1.add("惠农网荔枝商品名称词云图", [*zip(key_words.words, key_words.num)],
#           word_size_range=[20, 200],
#           shape=SymbolType.DIAMOND)
# word1.set_global_opts(  # title_opts=opts.TitleOpts('惠农网荔枝商品名称词云图'),
#     toolbox_opts=opts.ToolboxOpts())
# make_snapshot(driver, word1.render("惠农网荔枝商品名称词云图.html"), '惠农网荔枝商品名称词云图.png')
# os.system("惠农网荔枝商品名称词云图.html")
