from selenium import webdriver
from selenium.webdriver.common.by import By
import time, random
from bs4 import BeautifulSoup
import csv
import re


def search_product():
    driver.get('https://www.cnhnb.com/p/lizhi-0-297-0-0-1/')
    # 定位这个“页码”，获取“共100页这个文本”
    page_info = driver.find_element(By.XPATH, '//*[@id="__layout"]/div/div/div[2]/div/div[3]/div/div/a[8]').text
    page = re.findall("(\d+)", page_info)[0]        # findall()返回的是一个列表
    return page


def get_data(urls):
    for n, url in enumerate(urls):
        item = {}
        print(f'第{n + 1}个')
        driver.get(url)
        time.sleep(random.randint(2, 5))
        soup = BeautifulSoup(driver.page_source, 'lxml')
        time.sleep(random.randint(1, 3))
        name = soup.find_all('div', class_='d-t')[0].text
        price = float(soup.find_all('div', class_='active-p')[0].text[:4])
        batch = soup.find_all('div', class_='line-val')[0].text[:-2]
        loc = soup.find_all('div', class_='line-val')[1].text[-3:]
        hot = len(driver.find_elements(By.CLASS_NAME, 'fire-icon'))
        enquirys = soup.find_all('span', class_='s1')[0].text
        enquiry = re.sub(r'\D', '', enquirys)
        deals = soup.find_all('span', class_='s1')[1].text
        deal = int(re.sub(r'\D', '', deals))      # 删除非数字的字符串
        collects = driver.find_elements(By.XPATH, '//*[@id="__layout"]/div/div/div[3]/div[1]/div[1]/div/div[3]/div[1]')[
            0].text
        collect = int(re.sub(r'\D', '', collects))  # 删除非数字的字符串
        item['商品名'], item['价格'], item['起批量'], item['发货地址'], item['采购热度'], item['询价量'], item['成交量'], item[
            '收藏量'] = name, price, batch, loc, hot, enquiry, deal, collect
        print(item)
        data_li.append(item)


def save_data():
    with open('惠农网荔枝供应数据.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, ['商品名', '价格', '起批量', '发货地址', '采购热度', '询价量', '成交量', '收藏量'])
        writer.writeheader()
        writer.writerows(data_li)


def get_url():
    a_tags = driver.find_elements(By.XPATH, '//*[@id="__layout"]/div/div/div[2]/div/div[2]/div/div/a')
    time.sleep(random.randint(1, 2))
    for a_tag in a_tags:
        time.sleep(random.randint(1, 3))
        a_url = a_tag.get_attribute('href')
        print(a_url)
        urls.append(a_url)


def main():
    driver.get('https://www.cnhnb.com/')
    driver.find_element(By.XPATH, '//*[@id="__layout"]/div/div/div[1]/div[1]/div/div[1]/div[2]/div[1]').click()
    time.sleep(15)      # 等待15秒，给足时间我们扫码
    page = search_product()
    print(page)
    get_url()
    page_num = 1
    while int(page) != page_num:
        print("正在爬取第{}页".format(page_num + 1))
        driver.get('https://www.cnhnb.com/p/lizhi-0-297-0-0-{}/'.format(page_num + 1))
        driver.implicitly_wait(15)
        get_url()
        page_num += 1
    get_data(urls)
    save_data()
    print("数据爬取完毕并保存成功！")


if __name__ == '__main__':
    data_li, urls = [], []
    driver = webdriver.Chrome()
    main()
    driver.close()
