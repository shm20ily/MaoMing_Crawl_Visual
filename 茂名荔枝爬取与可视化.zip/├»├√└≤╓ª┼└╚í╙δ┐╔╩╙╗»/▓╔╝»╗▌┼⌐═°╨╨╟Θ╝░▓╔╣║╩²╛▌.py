# import random
# from selenium import webdriver
# from selenium.webdriver.common.by import By
# import time
# import csv
# import re
#
#
# def search_product():
#     # driver.get('https://www.cnhnb.com/purchase/lizhi-0-0-0-0-1/')
#     driver.get('https://www.cnhnb.com/hangqing/cdlist-2001302-0-19-0-0-1/')
#     # 定位这个“页码”，获取“共100页这个文本”
#     # page_info = driver.find_element(By.XPATH,
#     #                                 '//*[@id="__layout"]/div/div/div[2]/div/div[3]/div[1]/div[2]/div/a[8]').text
#     page_info = driver.find_element(By.XPATH,
#                                     '//*[@id="__layout"]/div/div/div[2]/div[1]/div[4]/div/div[1]/div[1]/div['
#                                     '2]/div/div/a[2]').text
#     page = re.findall("(\d+)", page_info)[0]  # findall()返回的是一个列表
#     return page
#
#
# def get_data():
#     # items = driver.find_elements(By.XPATH, '//*[@class="eye-flex eye-flex-wrap purchase-hot-item eye-renderer"]')
#     # for item in items:
#     #     for div in driver.find_elements(By.XPATH, './/div[@class="purchase-cell"]'):
#     #         breed = div.find_element(By.XPATH, './/div[@class="cateName cateName2"]').text
#     #         number = div.find_element(By.XPATH, './/div[@class="qty qty2"]').text
#     #         supply = div.find_element(By.XPATH, './/div[@class="scopeFullName scopeFullName2"]').text
#     #         print(breed, number, supply)
#     #         with open('惠农网荔枝采购数据.csv', 'a', newline='', encoding='utf-8') as f:
#     #             csv_writer = csv.writer(f, delimiter=',')
#     #             csv_writer.writerow([breed, number, supply])
#     items = driver.find_elements(By.XPATH, '//*[@class="quotation-content-list"]')
#     for item in items:
#         for li in driver.find_elements(By.XPATH, './/li[@class="market-list-item"]'):
#             time = li.find_element(By.XPATH, './/span[@class="time"]').text
#             breed = li.find_element(By.XPATH, './/span[@class="product"]').text
#             place = li.find_element(By.XPATH, './/span[@class="place"]').text
#             price = li.find_element(By.XPATH, './/span[@class="price"]').text
#             lifting = li.find_element(By.XPATH, './/span[last()-1]').text
#             print(time, breed, place, price, lifting)
#             with open('惠农网荔枝行情数据.csv', 'a', newline='', encoding='utf-8') as f:
#                 csv_writer = csv.writer(f, delimiter=',')
#                 csv_writer.writerow([time, breed, place, price, lifting])
#
#
# def main():
#     driver.get('https://www.cnhnb.com/')
#     driver.find_element(By.XPATH, '//*[@id="__layout"]/div/div/div[1]/div[1]/div/div[1]/div[2]/div[1]').click()
#     time.sleep(15)  # 等待15秒，给足时间我们扫码
#     page = search_product()
#     print(page)
#     get_data()
#     time.sleep(random.randint(5, 8))
#     page_num = 1
#     while int(page) != page_num:
#         print("正在爬取第{}页".format(page_num + 1))
#         # driver.get('https://www.cnhnb.com/purchase/lizhi-0-0-0-0-{}/'.format(page_num + 1))
#         driver.get('https://www.cnhnb.com/hangqing/cdlist-2001302-0-19-0-0-{}/'.format(page_num + 1))
#         time.sleep(random.randint(10, 15))
#         get_data()
#         page_num += 1
#     print("数据爬取完毕并保存成功！")
#
#
# if __name__ == '__main__':
#     data_li = []
#     driver = webdriver.Chrome()
#     main()
#     driver.close()


import pandas as pd

df = pd.read_csv('惠农网荔枝采购数据.csv', engine='python', encoding='utf-8-sig', header=None)
df.columns = ["产品/品质", "采购数量", "货源地"]
df1 = df[df['货源地'].str.contains('广东')]
df1.to_csv('惠农网广东荔枝采购数据.csv', encoding='utf-8-sig', index=False)
# df1['采购数量'] = df1['采购数量'].str.rstrip('斤')
# df1['采购数量'] = df1['采购数量'].astype('int64')
# # print(df1)
# sale_top10 = df1.groupby('货源地')['采购数量'].sum().sort_values(ascending=False).head(10)
# print(sale_top10)

from pyecharts.charts import Bar
from pyecharts import options as opts
import os
from snapshot_selenium import snapshot as driver
from pyecharts.render import make_snapshot

# # 绘制柱形图
# bar0 = Bar(init_opts=opts.InitOpts(width='1350px', height='750px'))
# bar0.add_xaxis(sale_top10.index.tolist())
# bar0.add_yaxis('惠农网广东各地区荔枝需求Top10', sale_top10.values.tolist())
# bar0.set_global_opts(  # title_opts=opts.TitleOpts(title='荔枝商品销量Top10'),
#     xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=-15), name='采购数量'),
#     yaxis_opts=opts.AxisOpts(name='地区'),
#     visualmap_opts=opts.VisualMapOpts(max_=sale_top10.values.max()))
# make_snapshot(driver, bar0.render("惠农网广东各地区荔枝需求Top10.html"), '惠农网广东各地区荔枝需求Top10.png')
# os.system("惠农网广东各地区荔枝需求Top10.html")
