import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from pyecharts.charts import Map
from snapshot_selenium import snapshot as driver
from pyecharts.render import make_snapshot
from pyecharts import options as opts
import os
from pyecharts.charts import Pie

# 加载字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
# 显示负号
plt.rcParams['axes.unicode_minus'] = False

df = pd.read_excel("./荔枝产业数据/2019年广东省茂名市荔枝产量（吨）.xlsx")
# df = pd.read_excel("./荔枝产业数据/2019年广东省荔枝种植面积（公顷）.xlsx")
df.set_index('时间', inplace=True)
# df.index = [2020, 2016, 2012, 2008, 2004, 2002, 1998, 1996, 1994, 1992]
# print(df)
# df.index.names = ['年份']
# df.to_excel("广东省荔枝面积和产量走势.xlsx")
# cols = ['茂名', '湛江', '汕尾', '阳江', '惠州', '揭阳', '广州', '云浮', '肇庆', '潮州', '江门', '梅州', '汕头',
#         '清远', '深圳', '河源', '珠海', '东莞', '中山', '佛山', '韶关']
# df.columns = cols
# df1 = pd.DataFrame(zip(df.iloc[0, :].values.tolist(), df.iloc[1, :].values.tolist()), index=df.columns.tolist(),
#                    columns=['2020年', '2019年'])
# df1.index.names = ['月份']

# df1 = pd.DataFrame(zip(df.columns.tolist(), df.values.ravel().tolist()), columns=['地区', '种植面积'])
# print(df1)
# df1.to_excel("2019年广东省茂名市荔枝种植面积（公顷）.xlsx")


data_pair = [list(z) for z in zip(df.columns.tolist(), df.values.ravel().tolist())]
print(data_pair)    # [['<0.5kg', 4.71], ['0.5kg≤X<2.5kg', 1044.82], ['2.5kg≤X<5kg', 2699.05], ['＞5kg', 17.33]]
# # 饼图
# pie1 = Pie(init_opts=opts.InitOpts(width='1350px', height='750px'))
# # 内置富文本
# pie1.add(
#     series_name="2020年荔枝电商各类规格销售额（万元）",
#     radius=["35%", "55%"],
#     data_pair=data_pair,
#     label_opts=opts.LabelOpts(formatter='{{b}—占比{d}%}\n{c}' + '万元'),
# )
# pie1.set_global_opts(legend_opts=opts.LegendOpts(pos_left="left", pos_top='30%', orient="vertical"),
#                      title_opts=opts.TitleOpts(title='2020年荔枝电商各类规格占比'),
#                      toolbox_opts=opts.ToolboxOpts())
# make_snapshot(driver, pie1.render("2020年荔枝电商各类规格销售额（万元）.html"), '2020年荔枝电商各类规格销售额（万元）.png')
# os.system("2020年荔枝电商各类规格销售额（万元）.html")


# # 设置图框的大小
# fig = plt.figure(figsize=(10, 6))
# # 绘图
# plt.plot(df.columns.tolist(),  # x轴数据
#          df.values.ravel().tolist(),  # y轴数据
#          linestyle='-',  # 折线类型
#          linewidth=2,  # 折线宽度
#          color='steelblue',  # 折线颜色
#          marker='o',  # 点的形状
#          markersize=6,  # 点的大小
#          markeredgecolor='black',  # 点的边框色
#          markerfacecolor='steelblue')  # 点的填充色
# # 添加标题和坐标轴标签
# plt.title('2020年规模化荔枝基地成本收益表（元亩）')
# plt.xlabel('荔枝各品种')
# plt.ylabel('成本收益（元亩）')
# for a, b in zip(df.columns.tolist(), df.values.ravel().tolist()):
#     plt.text(a, b + 0.05, b, ha='center', va='bottom', fontsize=18, color='blue')
# plt.savefig('2020年规模化荔枝基地成本收益表（元亩）.png')
# # 显示图形
# plt.show()


# x = df.index
# y1 = df.iloc[:, 0].values.tolist()
# y2 = df.iloc[:, 1].values.tolist()
# fig = plt.figure(figsize=(10, 6))
# for a, b in zip(x, y1):
#     plt.text(a, b - 1.6, b, ha='center', va='bottom', fontsize=18, color='blue')
# for c, d in zip(x, y2):
#     plt.text(c, d, d, ha='center', va='bottom', fontsize=18, color='orange')
# # 绘图--2020趋势
# l1 = plt.plot(x,  # x轴数据
#               y1,  # y轴数据
#               linestyle='-',  # 折线类型
#               linewidth=2,  # 折线宽度
#               color='steelblue',  # 折线颜色
#               marker='o',  # 点的形状
#               markersize=6,  # 点的大小
#               markeredgecolor='black',  # 点的边框色
#               markerfacecolor='steelblue',  # 点的填充色
#               label='2020年')  # 添加标签
# l2 = plt.plot(x,  # x轴数据
#               y2,  # y轴数据
#               linestyle='-',  # 折线类型
#               linewidth=2,  # 折线宽度
#               color='#ff9999',  # 折线颜色
#               marker='o',  # 点的形状
#               markersize=6,  # 点的大小
#               markeredgecolor='black',  # 点的边框色
#               markerfacecolor='#ff9999',  # 点的填充色
#               label='2019年')  # 添加标签
# plt.title('广东省荔枝面积和产量走势')
# plt.xlabel('年份')
# plt.ylabel('上市量（万吨)')
# # 显示图例
# plt.legend()
# # plt.savefig('广东省荔枝面积和产量走势.png')
# # 显示图形
# plt.show()


# area = list(zip(df.columns.tolist(), df.values.ravel().tolist()))
# print(area)
# # 绘制地图
# map = Map(init_opts=opts.InitOpts(width='1350px', height='750px'))
# map.add("2019年广东省茂名市荔枝产量（吨）.xlsx", [list(z) for z in zip(df.columns.tolist(), df.values.ravel().tolist())],
#         maptype='茂名')
# map.set_global_opts(visualmap_opts=opts.VisualMapOpts(max_=160000),
#                     toolbox_opts=opts.ToolboxOpts())
# make_snapshot(driver, map.render('2019年广东省茂名市荔枝产量（吨）.html'),
#               r'.\images\2019年广东省茂名市荔枝产量（吨）.png')
# os.system("2019年广东省茂名市荔枝产量（吨）.html")

# li = [[7849, 3443, 4406],
#       [10950, 3420, 7530],
#       [8523, 2990, 5533],
#       [5900, 2388, 3512],
#       [13800, 3926, 9874],
#       [4400, 1750, 2650]]
# df = pd.DataFrame(li, index=['妃子笑', '白糖罂', '桂味', '黑叶', '糯米糍', '怀枝'],
#                   columns=['亩均产值', '亩均成本', '亩均效益'])
# print(df)
# df.plot(style='--.', alpha=0.5)
# plt.ylabel('元/亩')
# plt.twinx()
# plt.plot(['妃子笑', '白糖罂', '桂味', '黑叶', '糯米糍', '怀枝'], [56.1, 68.8, 64.9, 59.5, 71.6, 60.2], marker='o',
#          markersize=3, color='r', label='利润率')
# plt.ylabel('利润率（%）')
# plt.title('2021年广东规模基地荔枝种植成本效益走势图')
# plt.legend()
# plt.savefig('2021年广东规模基地荔枝种植成本效益走势图')
# plt.show()

# li = [[8584, 3259, 5325],
#       [8216, 3731, 4485],
#       [13073, 2134, 9939],
#       [4763, 2876, 1887],
#       [14634, 2783, 11851],
#       [3313, 1833, 1480]]
# df = pd.DataFrame(li, index=['妃子笑', '白糖罂', '桂味', '黑叶', '糯米糍', '怀枝'],
#                   columns=['亩均产值', '亩均成本', '亩均效益'])
# print(df)
# df.plot(style='--.', alpha=0.5)
# plt.ylabel('元/亩')
# plt.twinx()
# plt.plot(['妃子笑', '白糖罂', '桂味', '黑叶', '糯米糍', '怀枝'], [922, 765, 538, 970, 508.3, 767], marker='o',
#          markersize=3, color='r', label='亩均产量')
# plt.ylabel('公斤/亩')
# plt.title('2020年广东规模基地荔枝种植成本效益走势图')
# plt.legend()
# plt.tight_layout()
# # plt.savefig('2020年广东规模基地荔枝种植成本效益走势图.png')
# plt.show()

# plt.plot(['妃子笑', '白糖罂', '桂味', '黑叶', '糯米糍', '怀枝'], [9.3, 10.7, 24.3, 4.9, 28.8, 4.3], marker='o',
#          markersize=3, label='田头均价')
# plt.title('2020年监测主要荔枝品种田头价走势图')
# plt.ylabel('元/公斤')
# plt.legend()
# plt.savefig('2020年监测主要荔枝品种田头价走势图.png')
# plt.show()

# bar_width = 0.35
# # 绘图
# plt.bar(np.arange(1), [2910], color='steelblue', alpha=0.8, width=bar_width)
# plt.bar(np.arange(1) + bar_width, [5156], color='indianred', alpha=0.8, width=bar_width)
# # 添加轴标签
# # plt.xlabel('Top5城市')
# plt.ylabel('家庭数量')
# # 添加标题
# plt.title('亿万财富家庭数Top5城市分布')
# # # 添加刻度标签
# plt.xticks(np.arange(2) + bar_width, [2021, 2022])
# # 设置Y轴的刻度范围
# plt.ylim([2500, 19000])

# # 为每个条形图添加数值标签
# for x2016, y2016 in enumerate(Y2016):
#     plt.text(x2016, y2016 + 100, '%s' % y2016)
#
# for x2017, y2017 in enumerate(Y2017):
#     plt.text(x2017 + bar_width, y2017 + 100, '%s' % y2017)
# 显示图例
# plt.legend()
# 显示图形
# plt.show()
